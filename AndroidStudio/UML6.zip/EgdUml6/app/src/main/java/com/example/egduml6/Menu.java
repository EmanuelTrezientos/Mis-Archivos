package com.example.egduml6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        getSupportActionBar().hide();
        Button Boton3;
        Button Boton4;

        Boton3 = findViewById(R.id.AtrasBoton);
        Boton4 = findViewById(R.id.BotonRegistrarse);

        Boton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent siguiente = new Intent(getApplicationContext(),Login.class);
                startActivity(siguiente);
            }
        });

        Boton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent siguiente = new Intent(getApplicationContext(),Rh.class);
                startActivity(siguiente);
            }
        });
    }

}